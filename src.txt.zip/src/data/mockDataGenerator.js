const fs = require('fs');
const path = require('path');

const raw_config = require('./config.json');

const dailyData = [];
const hourlyData = [];

const areas = ['MainFloor', 'HighLimit', 'VIP'];
const dows = ['WD', 'WE'];
const manufacturers = ['IGT', 'ARISTOCRAT', 'LIGHT & WONDER', 'KONAMI'];
const games = ['BA', 'SB', 'AP', 'ETG', 'LINK'];
const jackpotLinks = ['Dragon Link', 'Hot Pot Link', 'Lightning Link', 'Choy Sun Doa Link', 'Grand Star Link'];

// Step 1: Assign a persistent asset ID to each configuration location
const locationAssets = {};
raw_config.forEach(conf => {
    // Generate a random 5-digit asset number as text
    const assetId = Math.floor(10000 + Math.random() * 90000).toString();
    locationAssets[conf.location] = assetId;
    conf.asset = assetId; // Update config object
});

// Write updated config back to disk
fs.writeFileSync(path.join(__dirname, 'config.json'), JSON.stringify(raw_config, null, 4));
console.log('Updated config.json with asset IDs');

// Generate 30 days of data (March 16 - April 14, 2026)
const endDate = new Date('2026-04-14');

raw_config.forEach(conf => {
    if (conf.is_Active === 1 || conf.is_Active === "1") {
        const asset = locationAssets[conf.location];
        const link = conf.game === 'LINK' ? jackpotLinks[Math.floor(Math.random() * jackpotLinks.length)] : 'None';

        for (let dayOffset = 0; dayOffset < 30; dayOffset++) {
            const d = new Date(endDate);
            d.setDate(d.getDate() - dayOffset);
            const dateStr = d.toISOString().slice(0, 10);
            const dayOfWeek = d.getDay(); // 0=Sun, 6=Sat
            const dow = (dayOfWeek === 0 || dayOfWeek === 6) ? 'WE' : 'WD';

            // Daily Data
            dailyData.push({
                location: conf.location,
                asset: asset,
                date: dateStr,
                area: conf.area,
                manufacturer: conf.manufacturer,
                gametype: conf.game,
                link: link,
                dow: dow,
                turnover: Math.floor(Math.random() * 50000) + 1000,
                win: Math.floor(Math.random() * 10000),
                theo: Math.floor(Math.random() * 8000),
                rated_theo: Math.floor(Math.random() * 6000),
                games: Math.floor(Math.random() * 5000) + 100,
                played_mins: Math.floor(Math.random() * 1440),
                floor_mins: 1440,
                core_played_mins: Math.floor(Math.random() * 400),
                core_floor_mins: 400,
                mday: 1,
                denom_array: {
                    '0.05': Math.floor(Math.random() * 10),
                    '0.1': Math.floor(Math.random() * 5),
                    '0.2': Math.floor(Math.random() * 3),
                    '0.5': Math.floor(Math.random() * 3),
                    '1': Math.floor(Math.random() * 2),
                    '2': 0,
                    '5': 0,
                    '10': 0,
                    '20': 0
                }
            });

            // Hourly Data (24 records per day)
            for (let hour = 0; hour < 24; hour++) {
                hourlyData.push({
                    location: conf.location,
                    asset: asset,
                    date: dateStr,
                    hour: hour,
                    area: conf.area,
                    manufacturer: conf.manufacturer,
                    gametype: conf.game,
                    link: link,
                    dow: dow,
                    turnover: Math.floor(Math.random() * 3000) + 50,
                    win: Math.floor(Math.random() * 600),
                    theo: Math.floor(Math.random() * 500),
                    rated_theo: Math.floor(Math.random() * 400),
                    games: Math.floor(Math.random() * 300) + 10,
                    played_mins: Math.floor(Math.random() * 60),
                    floor_mins: 60,
                    core_played_mins: Math.floor(Math.random() * 20),
                    core_floor_mins: 20,
                    mday: 1/24,
                    denom_array: {
                        '0.05': Math.floor(Math.random() * 5),
                        '0.1': Math.floor(Math.random() * 3),
                        '0.2': Math.floor(Math.random() * 2),
                        '0.5': Math.floor(Math.random() * 2),
                        '1': Math.floor(Math.random() * 1),
                        '2': 0,
                        '5': 0,
                        '10': 0,
                        '20': 0
                    }
                });
            }
        }
    }
});

fs.writeFileSync(path.join(__dirname, 'slot_heatmap_data.json'), JSON.stringify(dailyData, null, 2));
fs.writeFileSync(path.join(__dirname, 'slot_hourly_data.json'), JSON.stringify(hourlyData, null, 2));

console.log(`Mock Daily dataset generated -> slot_heatmap_data.json (${dailyData.length} rows)`);
console.log(`Mock Hourly dataset generated -> slot_hourly_data.json (${hourlyData.length} rows)`);
