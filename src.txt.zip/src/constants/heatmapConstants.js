export const SVG_PATHS = {
    LTG: { path: 'M56 395.063 212 395.063 212 552.088 56.4419 552.088 56 395.063Z', sizeX: 7, sizeY: 7 },
    LINK: { path: 'M56 395.063 212 395.063 212 552.088 56.4419 552.088 56 395.063Z', sizeX: 7, sizeY: 7 },
    ETG: { path: 'M56 395.063 212 395.063 212 552.088 56.4419 552.088 56 395.063Z', sizeX: 7, sizeY: 7 },
    STANDALONE: { path: 'M56 395.063 212 395.063 212 552.088 56.4419 552.088 56 395.063Z', sizeX: 7, sizeY: 7 },
    'STANDALONE ETG': { path: 'M56 395.063 212 395.063 212 552.088 56.4419 552.088 56 395.063Z', sizeX: 7, sizeY: 7 },
};

export const GAMETYPE_COLORS = {
    'LTG': '#0AFA6C',
    'ETG': '#0E98FA',
    'STANDALONE': '#FA0501',
    'STANDALONE ETG': '#F6984C',
    'LINK': '#FFFF33',
    'Decomm': '#404040',
};

export const MANUFACTURER_COLORS = {
    'AINSWORTH': '#E63946',
    'ARISTOCRAT': '#F77F00',
    'ARUZE': '#0aff0aff',
    'IGT': '#FFD60A',
    'INTERBLOCK': '#2A9D8F',
    'KONAMI': '#118AB2',
    'LIGHT & WONDER': '#5A189A',
    'LT GAME': '#200376ff',
    'SEGA SAMMY': '#E5389E',
    'SPINTEC': '#8D6E63',
};

export const LINK_COLORS = {
    'Dragon Link': '#FF4D4D',
    'Hot Pot Link': '#FFA500',
    'Lightning Link': '#FFFF00',
    'Choy Sun Doa Link': '#32CD32',
    'Grand Star Link': '#00BFFF',
    'None': '#404040'
};

export const THRESHOLDS = {
    'Turnover per unit per day': [
        { gte: 100000, color: 'rgba(255, 0, 0)', label: '100k up' },
        { gte: 80000, lt: 100000, color: 'rgba(251, 155, 210)', label: '80k - 100k' },
        { gte: 60000, lt: 80000, color: 'rgba(242, 141, 30)', label: '60k - 80k' },
        { gte: 45000, lt: 60000, color: 'rgba(244, 238, 12)', label: '45k - 60k' },
        { gte: 30000, lt: 45000, color: 'rgba(196, 215, 155)', label: '30k - 45k' },
        { gte: 20000, lt: 30000, color: 'rgba(6, 142, 34)', label: '20k - 30k' },
        { gte: 10000, lt: 20000, color: 'rgba(97, 135, 255)', label: '10k - 20k' },
        { gte: 0, lt: 10000, color: 'rgba(0, 60, 180)', label: '10k below' },
    ],
    'GGR per unit per day': [
        { gte: 10000, color: 'rgba(255, 0, 0)', label: '10k up' },
        { gte: 8000, lt: 10000, color: 'rgba(251, 155, 210)', label: '8k - 10k' },
        { gte: 6000, lt: 8000, color: 'rgba(242, 141, 30)', label: '6k - 8k' },
        { gte: 4500, lt: 6000, color: 'rgba(244, 238, 12)', label: '4.5k - 6k' },
        { gte: 3000, lt: 4500, color: 'rgba(196, 215, 155)', label: '3k - 4.5k' },
        { gte: 2000, lt: 3000, color: 'rgba(6, 142, 34)', label: '2k - 3k' },
        { gte: 1000, lt: 2000, color: 'rgba(97, 135, 255)', label: '1k - 2k' },
        { gte: -999990, lt: 1000, color: 'rgba(0, 60, 180)', label: '1k below' },
    ],
    'Theo per unit per day': [
        { gte: 10000, color: 'rgba(255, 0, 0)', label: '10k up' },
        { gte: 8000, lt: 10000, color: 'rgba(251, 155, 210)', label: '8k - 10k' },
        { gte: 6000, lt: 8000, color: 'rgba(242, 141, 30)', label: '6k - 8k' },
        { gte: 4500, lt: 6000, color: 'rgba(244, 238, 12)', label: '4.5k - 6k' },
        { gte: 3000, lt: 4500, color: 'rgba(196, 215, 155)', label: '3k - 4.5k' },
        { gte: 2000, lt: 3000, color: 'rgba(6, 142, 34)', label: '2k - 3k' },
        { gte: 1000, lt: 2000, color: 'rgba(97, 135, 255)', label: '1k - 2k' },
        { gte: 0, lt: 1000, color: 'rgba(0, 60, 180)', label: '1k below' },
    ],
    'Utilization': [
        { gte: 0.9, color: 'rgba(255, 0, 0)', label: '90%+' },
        { gte: 0.8, lt: 0.9, color: 'rgba(158, 0, 158)', label: '80% - 89.9%' },
        { gte: 0.7, lt: 0.8, color: 'rgba(190, 103, 243)', label: '70% - 79.9%' },
        { gte: 0.6, lt: 0.7, color: 'rgba(251, 155, 210)', label: '60% - 69.9%' },
        { gte: 0.5, lt: 0.6, color: 'rgba(242, 141, 30)', label: '50% - 59.9%' },
        { gte: 0.4, lt: 0.5, color: 'rgba(244, 238, 12)', label: '40% - 49.9%' },
        { gte: 0.3, lt: 0.4, color: 'rgba(196, 215, 155)', label: '30% - 39.9%' },
        { gte: 0.2, lt: 0.3, color: 'rgba(6, 142, 34)', label: '20% - 29.9%' },
        { gte: 0.1, lt: 0.2, color: 'rgba(97, 135, 255)', label: '10% - 19.9%' },
        { gte: 0.00001, lt: 0.1, color: 'rgba(0, 60, 180)', label: '0.1% - 9.9%' },
    ],
    'Denomination': [
        { gte: 800, color: 'rgba(255, 0, 0)', label: '800' },
        { gte: 500, lt: 800, color: 'rgba(255, 64, 0)', label: '500' },
        { gte: 200, lt: 500, color: 'rgba(255, 128, 0)', label: '200' },
        { gte: 100, lt: 200, color: 'rgba(255, 192, 0)', label: '100' },
        { gte: 50, lt: 100, color: 'rgba(255, 255, 0)', label: '50' },
        { gte: 30, lt: 50, color: 'rgba(192, 255, 0)', label: '30' },
        { gte: 20, lt: 30, color: 'rgba(128, 255, 0)', label: '20' },
        { gte: 10, lt: 20, color: 'rgba(0, 255, 0)', label: '10' },
        { gte: 5, lt: 10, color: 'rgba(0, 255, 128)', label: '5' },
        { gte: 1, lt: 5, color: 'rgba(0, 192, 255)', label: '1' },
        { gte: 0.5, lt: 1, color: 'rgba(0, 128, 255)', label: '0.5' },
        { gte: 0.1, lt: 0.5, color: 'rgba(0, 0, 255)', label: '0.1' },
        { gte: 0.05, lt: 0.1, color: 'rgba(0, 0, 192)', label: '0.05' },
    ],
    'Rated Theo per unit per day': [
        { gte: 10000, color: 'rgba(255, 0, 0)', label: '10k up' },
        { gte: 8000, lt: 10000, color: 'rgba(251, 155, 210)', label: '8k - 10k' },
        { gte: 6000, lt: 8000, color: 'rgba(242, 141, 30)', label: '6k - 8k' },
        { gte: 4500, lt: 6000, color: 'rgba(244, 238, 12)', label: '4.5k - 6k' },
        { gte: 3000, lt: 4500, color: 'rgba(196, 215, 155)', label: '3k - 4.5k' },
        { gte: 2000, lt: 3000, color: 'rgba(6, 142, 34)', label: '2k - 3k' },
        { gte: 1000, lt: 2000, color: 'rgba(97, 135, 255)', label: '1k - 2k' },
        { gte: 0, lt: 1000, color: 'rgba(0, 60, 180)', label: '1k below' },
    ],
    'Pulls per unit per day': [
        { gte: 3000, color: 'rgba(255, 0, 0)', label: '3000+' },
        { gte: 2500, lt: 3000, color: 'rgba(251, 155, 210)', label: '2.5k - 3k' },
        { gte: 2000, lt: 2500, color: 'rgba(242, 141, 30)', label: '2k - 2.5k' },
        { gte: 1500, lt: 2000, color: 'rgba(244, 238, 12)', label: '1.5k - 2k' },
        { gte: 1000, lt: 1500, color: 'rgba(196, 215, 155)', label: '1k - 1.5k' },
        { gte: 500, lt: 1000, color: 'rgba(6, 142, 34)', label: '500 - 1k' },
        { gte: 100, lt: 500, color: 'rgba(97, 135, 255)', label: '100 - 500' },
        { gte: 0, lt: 100, color: 'rgba(0, 60, 180)', label: '100 below' },
    ],
    'Average Bet': [
        { gte: 500, color: 'rgba(255, 0, 0)', label: '500+' },
        { gte: 300, lt: 500, color: 'rgba(251, 155, 210)', label: '300 - 500' },
        { gte: 200, lt: 300, color: 'rgba(242, 141, 30)', label: '200 - 300' },
        { gte: 100, lt: 200, color: 'rgba(244, 238, 12)', label: '100 - 200' },
        { gte: 50, lt: 100, color: 'rgba(196, 215, 155)', label: '50 - 100' },
        { gte: 25, lt: 50, color: 'rgba(6, 142, 34)', label: '25 - 50' },
        { gte: 10, lt: 25, color: 'rgba(97, 135, 255)', label: '10 - 25' },
        { gte: 0, lt: 10, color: 'rgba(0, 60, 180)', label: '10 below' },
    ],
    'Core Utilization': [
        { gte: 0.9, color: 'rgba(255, 0, 0)', label: '90%+' },
        { gte: 0.8, lt: 0.9, color: 'rgba(158, 0, 158)', label: '80% - 89.9%' },
        { gte: 0.7, lt: 0.8, color: 'rgba(190, 103, 243)', label: '70% - 79.9%' },
        { gte: 0.6, lt: 0.7, color: 'rgba(251, 155, 210)', label: '60% - 69.9%' },
        { gte: 0.5, lt: 0.6, color: 'rgba(242, 141, 30)', label: '50% - 59.9%' },
        { gte: 0.4, lt: 0.5, color: 'rgba(244, 238, 12)', label: '40% - 49.9%' },
        { gte: 0.3, lt: 0.4, color: 'rgba(196, 215, 155)', label: '30% - 39.9%' },
        { gte: 0.2, lt: 0.3, color: 'rgba(6, 142, 34)', label: '20% - 29.9%' },
        { gte: 0.1, lt: 0.2, color: 'rgba(97, 135, 255)', label: '10% - 19.9%' },
        { gte: 0.00001, lt: 0.1, color: 'rgba(0, 60, 180)', label: '0.1% - 9.9%' },
    ],
};

export const MASS_THRESHOLDS = {
    'Turnover per unit per day': [
        { gte: 50000, color: 'rgba(255, 0, 0)', label: '50k up' },
        { gte: 40000, lt: 50000, color: 'rgba(251, 155, 210)', label: '40k - 50k' },
        { gte: 30000, lt: 40000, color: 'rgba(242, 141, 30)', label: '30k - 40k' },
        { gte: 22500, lt: 30000, color: 'rgba(244, 238, 12)', label: '22.5k - 30k' },
        { gte: 15000, lt: 22500, color: 'rgba(196, 215, 155)', label: '15k - 22.5k' },
        { gte: 10000, lt: 15000, color: 'rgba(6, 142, 34)', label: '10k - 15k' },
        { gte: 5000, lt: 10000, color: 'rgba(97, 135, 255)', label: '5k - 10k' },
        { gte: 0, lt: 5000, color: 'rgba(0, 60, 180)', label: '5k below' },
    ],
    'GGR per unit per day': [
        { gte: 5000, color: 'rgba(255, 0, 0)', label: '5k up' },
        { gte: 4000, lt: 5000, color: 'rgba(251, 155, 210)', label: '4k - 5k' },
        { gte: 3000, lt: 4000, color: 'rgba(242, 141, 30)', label: '3k - 4k' },
        { gte: 2250, lt: 3000, color: 'rgba(244, 238, 12)', label: '2.25k - 3k' },
        { gte: 1500, lt: 2250, color: 'rgba(196, 215, 155)', label: '1.5k - 2.25k' },
        { gte: 1000, lt: 1500, color: 'rgba(6, 142, 34)', label: '1k - 1.5k' },
        { gte: 500, lt: 1000, color: 'rgba(97, 135, 255)', label: '500 - 1k' },
        { gte: -999990, lt: 500, color: 'rgba(0, 60, 180)', label: '500 below' },
    ],
    'Theo per unit per day': [
        { gte: 5000, color: 'rgba(255, 0, 0)', label: '5k up' },
        { gte: 4000, lt: 5000, color: 'rgba(251, 155, 210)', label: '4k - 5k' },
        { gte: 3000, lt: 4000, color: 'rgba(242, 141, 30)', label: '3k - 4k' },
        { gte: 2250, lt: 3000, color: 'rgba(244, 238, 12)', label: '2.25k - 3k' },
        { gte: 1500, lt: 2250, color: 'rgba(196, 215, 155)', label: '1.5k - 2.25k' },
        { gte: 1000, lt: 1500, color: 'rgba(6, 142, 34)', label: '1k - 1.5k' },
        { gte: 500, lt: 1000, color: 'rgba(97, 135, 255)', label: '500 - 1k' },
        { gte: 0, lt: 500, color: 'rgba(0, 60, 180)', label: '500 below' },
    ],
    'Rated Theo per unit per day': [
        { gte: 5000, color: 'rgba(255, 0, 0)', label: '5k up' },
        { gte: 4000, lt: 5000, color: 'rgba(251, 155, 210)', label: '4k - 5k' },
        { gte: 3000, lt: 4000, color: 'rgba(242, 141, 30)', label: '3k - 4k' },
        { gte: 2250, lt: 3000, color: 'rgba(244, 238, 12)', label: '2.25k - 3k' },
        { gte: 1500, lt: 2250, color: 'rgba(196, 215, 155)', label: '1.5k - 2.25k' },
        { gte: 1000, lt: 1500, color: 'rgba(6, 142, 34)', label: '1k - 1.5k' },
        { gte: 500, lt: 1000, color: 'rgba(97, 135, 255)', label: '500 - 1k' },
        { gte: 0, lt: 500, color: 'rgba(0, 60, 180)', label: '500 below' },
    ],
    'Pulls per unit per day': [
        { gte: 1500, color: 'rgba(255, 0, 0)', label: '1500+' },
        { gte: 1250, lt: 1500, color: 'rgba(251, 155, 210)', label: '1.25k - 1.5k' },
        { gte: 1000, lt: 1250, color: 'rgba(242, 141, 30)', label: '1k - 1.25k' },
        { gte: 750, lt: 1000, color: 'rgba(244, 238, 12)', label: '750 - 1k' },
        { gte: 500, lt: 750, color: 'rgba(196, 215, 155)', label: '500 - 750' },
        { gte: 250, lt: 500, color: 'rgba(6, 142, 34)', label: '250 - 500' },
        { gte: 50, lt: 250, color: 'rgba(97, 135, 255)', label: '50 - 250' },
        { gte: 0, lt: 50, color: 'rgba(0, 60, 180)', label: '50 below' },
    ],
    'Average Bet': [
        { gte: 250, color: 'rgba(255, 0, 0)', label: '250+' },
        { gte: 150, lt: 250, color: 'rgba(251, 155, 210)', label: '150 - 250' },
        { gte: 100, lt: 150, color: 'rgba(242, 141, 30)', label: '100 - 150' },
        { gte: 50, lt: 100, color: 'rgba(244, 238, 12)', label: '50 - 100' },
        { gte: 25, lt: 50, color: 'rgba(196, 215, 155)', label: '25 - 50' },
        { gte: 12, lt: 25, color: 'rgba(6, 142, 34)', label: '12 - 25' },
        { gte: 5, lt: 12, color: 'rgba(97, 135, 255)', label: '5 - 12' },
        { gte: 0, lt: 5, color: 'rgba(0, 60, 180)', label: '5 below' },
    ],
    'Utilization': [
        { gte: 0.45, color: 'rgba(255, 0, 0)', label: '45%+' },
        { gte: 0.4, lt: 0.45, color: 'rgba(158, 0, 158)', label: '40% - 44.9%' },
        { gte: 0.35, lt: 0.4, color: 'rgba(190, 103, 243)', label: '35% - 39.9%' },
        { gte: 0.3, lt: 0.35, color: 'rgba(251, 155, 210)', label: '30% - 34.9%' },
        { gte: 0.25, lt: 0.3, color: 'rgba(242, 141, 30)', label: '25% - 29.9%' },
        { gte: 0.2, lt: 0.25, color: 'rgba(244, 238, 12)', label: '20% - 24.9%' },
        { gte: 0.15, lt: 0.2, color: 'rgba(196, 215, 155)', label: '15% - 19.9%' },
        { gte: 0.1, lt: 0.15, color: 'rgba(6, 142, 34)', label: '10% - 14.9%' },
        { gte: 0.05, lt: 0.1, color: 'rgba(97, 135, 255)', label: '5% - 9.9%' },
        { gte: 0.00001, lt: 0.05, color: 'rgba(0, 60, 180)', label: '0.1% - 4.9%' },
    ],
    'Core Utilization': [
        { gte: 0.45, color: 'rgba(255, 0, 0)', label: '45%+' },
        { gte: 0.4, lt: 0.45, color: 'rgba(158, 0, 158)', label: '40% - 44.9%' },
        { gte: 0.35, lt: 0.4, color: 'rgba(190, 103, 243)', label: '35% - 39.9%' },
        { gte: 0.3, lt: 0.35, color: 'rgba(251, 155, 210)', label: '30% - 34.9%' },
        { gte: 0.25, lt: 0.3, color: 'rgba(242, 141, 30)', label: '25% - 29.9%' },
        { gte: 0.2, lt: 0.25, color: 'rgba(244, 238, 12)', label: '20% - 24.9%' },
        { gte: 0.15, lt: 0.2, color: 'rgba(196, 215, 155)', label: '15% - 19.9%' },
        { gte: 0.1, lt: 0.15, color: 'rgba(6, 142, 34)', label: '10% - 14.9%' },
        { gte: 0.05, lt: 0.1, color: 'rgba(97, 135, 255)', label: '5% - 9.9%' },
        { gte: 0.00001, lt: 0.05, color: 'rgba(0, 60, 180)', label: '0.1% - 4.9%' },
    ],
    // Denomination stays the same
    'Denomination': THRESHOLDS['Denomination']
};

export const PREMIUM_THRESHOLDS = {
    'Turnover per unit per day': [
        { gte: 300000, color: 'rgba(255, 0, 0)', label: '300k up' },
        { gte: 240000, lt: 300000, color: 'rgba(251, 155, 210)', label: '240k - 300k' },
        { gte: 180000, lt: 240000, color: 'rgba(242, 141, 30)', label: '180k - 240k' },
        { gte: 135000, lt: 180000, color: 'rgba(244, 238, 12)', label: '135k - 180k' },
        { gte: 90000, lt: 135000, color: 'rgba(196, 215, 155)', label: '90k - 135k' },
        { gte: 60000, lt: 90000, color: 'rgba(6, 142, 34)', label: '60k - 90k' },
        { gte: 30000, lt: 60000, color: 'rgba(97, 135, 255)', label: '30k - 60k' },
        { gte: 0, lt: 30000, color: 'rgba(0, 60, 180)', label: '30k below' },
    ],
    'GGR per unit per day': [
        { gte: 30000, color: 'rgba(255, 0, 0)', label: '30k up' },
        { gte: 24000, lt: 30000, color: 'rgba(251, 155, 210)', label: '24k - 30k' },
        { gte: 18000, lt: 24000, color: 'rgba(242, 141, 30)', label: '18k - 24k' },
        { gte: 13500, lt: 18000, color: 'rgba(244, 238, 12)', label: '13.5k - 18k' },
        { gte: 9000, lt: 13500, color: 'rgba(196, 215, 155)', label: '9k - 13.5k' },
        { gte: 6000, lt: 9000, color: 'rgba(6, 142, 34)', label: '6k - 9k' },
        { gte: 3000, lt: 6000, color: 'rgba(97, 135, 255)', label: '3k - 6k' },
        { gte: -999990, lt: 3000, color: 'rgba(0, 60, 180)', label: '3k below' },
    ],
    'Theo per unit per day': [
        { gte: 30000, color: 'rgba(255, 0, 0)', label: '30k up' },
        { gte: 24000, lt: 30000, color: 'rgba(251, 155, 210)', label: '24k - 30k' },
        { gte: 18000, lt: 24000, color: 'rgba(242, 141, 30)', label: '18k - 24k' },
        { gte: 13500, lt: 18000, color: 'rgba(244, 238, 12)', label: '13.5k - 18k' },
        { gte: 9000, lt: 13500, color: 'rgba(196, 215, 155)', label: '9k - 13.5k' },
        { gte: 6000, lt: 9000, color: 'rgba(6, 142, 34)', label: '6k - 9k' },
        { gte: 3000, lt: 6000, color: 'rgba(97, 135, 255)', label: '3k - 6k' },
        { gte: 0, lt: 3000, color: 'rgba(0, 60, 180)', label: '3k below' },
    ],
    'Rated Theo per unit per day': [
        { gte: 30000, color: 'rgba(255, 0, 0)', label: '30k up' },
        { gte: 24000, lt: 30000, color: 'rgba(251, 155, 210)', label: '24k - 30k' },
        { gte: 18000, lt: 24000, color: 'rgba(242, 141, 30)', label: '18k - 24k' },
        { gte: 13500, lt: 18000, color: 'rgba(244, 238, 12)', label: '13.5k - 18k' },
        { gte: 9000, lt: 13500, color: 'rgba(196, 215, 155)', label: '9k - 13.5k' },
        { gte: 6000, lt: 9000, color: 'rgba(6, 142, 34)', label: '6k - 9k' },
        { gte: 3000, lt: 6000, color: 'rgba(97, 135, 255)', label: '3k - 6k' },
        { gte: 0, lt: 3000, color: 'rgba(0, 60, 180)', label: '3k below' },
    ],
    'Pulls per unit per day': [
        { gte: 9000, color: 'rgba(255, 0, 0)', label: '9000+' },
        { gte: 7500, lt: 9000, color: 'rgba(251, 155, 210)', label: '7.5k - 9k' },
        { gte: 6000, lt: 7500, color: 'rgba(242, 141, 30)', label: '6k - 7.5k' },
        { gte: 4500, lt: 6000, color: 'rgba(244, 238, 12)', label: '4.5k - 6k' },
        { gte: 3000, lt: 4500, color: 'rgba(196, 215, 155)', label: '3k - 4.5k' },
        { gte: 1500, lt: 3000, color: 'rgba(6, 142, 34)', label: '1.5k - 3k' },
        { gte: 300, lt: 1500, color: 'rgba(97, 135, 255)', label: '300 - 1.5k' },
        { gte: 0, lt: 300, color: 'rgba(0, 60, 180)', label: '300 below' },
    ],
    'Average Bet': [
        { gte: 1500, color: 'rgba(255, 0, 0)', label: '1500+' },
        { gte: 900, lt: 1500, color: 'rgba(251, 155, 210)', label: '900 - 1500' },
        { gte: 600, lt: 900, color: 'rgba(242, 141, 30)', label: '600 - 900' },
        { gte: 300, lt: 600, color: 'rgba(244, 238, 12)', label: '300 - 600' },
        { gte: 150, lt: 300, color: 'rgba(196, 215, 155)', label: '150 - 300' },
        { gte: 75, lt: 150, color: 'rgba(6, 142, 34)', label: '75 - 150' },
        { gte: 30, lt: 75, color: 'rgba(97, 135, 255)', label: '30 - 75' },
        { gte: 0, lt: 30, color: 'rgba(0, 60, 180)', label: '30 below' },
    ],
    'Utilization': [
        { gte: 0.9, color: 'rgba(255, 0, 0)', label: '90%+' },
        { gte: 0.8, lt: 0.9, color: 'rgba(158, 0, 158)', label: '80% - 89.9%' },
        { gte: 0.7, lt: 0.8, color: 'rgba(190, 103, 243)', label: '70% - 79.9%' },
        { gte: 0.6, lt: 0.7, color: 'rgba(251, 155, 210)', label: '60% - 69.9%' },
        { gte: 0.5, lt: 0.6, color: 'rgba(242, 141, 30)', label: '50% - 59.9%' },
        { gte: 0.4, lt: 0.5, color: 'rgba(244, 238, 12)', label: '40% - 49.9%' },
        { gte: 0.3, lt: 0.4, color: 'rgba(196, 215, 155)', label: '30% - 39.9%' },
        { gte: 0.2, lt: 0.3, color: 'rgba(6, 142, 34)', label: '20% - 29.9%' },
        { gte: 0.1, lt: 0.2, color: 'rgba(97, 135, 255)', label: '10% - 19.9%' },
        { gte: 0.00001, lt: 0.1, color: 'rgba(0, 60, 180)', label: '0.1% - 9.9%' },
    ],
    'Core Utilization': [
        { gte: 0.9, color: 'rgba(255, 0, 0)', label: '90%+' },
        { gte: 0.8, lt: 0.9, color: 'rgba(158, 0, 158)', label: '80% - 89.9%' },
        { gte: 0.7, lt: 0.8, color: 'rgba(190, 103, 243)', label: '70% - 79.9%' },
        { gte: 0.6, lt: 0.7, color: 'rgba(251, 155, 210)', label: '60% - 69.9%' },
        { gte: 0.5, lt: 0.6, color: 'rgba(242, 141, 30)', label: '50% - 59.9%' },
        { gte: 0.4, lt: 0.5, color: 'rgba(244, 238, 12)', label: '40% - 49.9%' },
        { gte: 0.3, lt: 0.4, color: 'rgba(196, 215, 155)', label: '30% - 39.9%' },
        { gte: 0.2, lt: 0.3, color: 'rgba(6, 142, 34)', label: '20% - 29.9%' },
        { gte: 0.1, lt: 0.2, color: 'rgba(97, 135, 255)', label: '10% - 19.9%' },
        { gte: 0.00001, lt: 0.1, color: 'rgba(0, 60, 180)', label: '0.1% - 9.9%' },
    ],
    'Denomination': THRESHOLDS['Denomination']
};

export const DAILY_KPI_LIST = [
    'Gametype',
    'Turnover per unit per day',
    'GGR per unit per day',
    'Theo per unit per day',
    'Rated Theo per unit per day',
    'Pulls per unit per day',
    'Average Bet',
    'Utilization',
    'Core Utilization',
    'Denomination',
    'Manufacturer',
    'Link',
];

export const HOURLY_KPI_LIST = [
    'Gametype',
    'Turnover per unit per day',
    'GGR per unit per day',
    'Theo per unit per day',
    'Rated Theo per unit per day',
    'Pulls per unit per day',
    'Average Bet',
    'Utilization',
    'Denomination',
    'Manufacturer',
    'Link',
];

export const KPI_FIELD_MAP = {
    'Turnover per unit per day': 'turnover',
    'GGR per unit per day': 'win',
    'Theo per unit per day': 'theo',
    'Rated Theo per unit per day': 'rated_theo',
    'Pulls per unit per day': 'pulls',
    'Average Bet': 'avgBet',
    'Utilization': 'utilization',
    'Core Utilization': 'coreUtilization',
    'Denomination': 'denomination',
    'Gametype': 'game',
    'Manufacturer': 'manufacturer',
    'Link': 'link',
};

export const KPI_RATIO_MAP = {
    'Turnover per unit per day': { num: 'raw_turnover', den: 'raw_mday' },
    'GGR per unit per day': { num: 'raw_win', den: 'raw_mday' },
    'Theo per unit per day': { num: 'raw_theo', den: 'raw_mday' },
    'Rated Theo per unit per day': { num: 'raw_rated_theo', den: 'raw_mday' },
    'Pulls per unit per day': { num: 'raw_games', den: 'raw_mday' },
    'Average Bet': { num: 'raw_turnover', den: 'raw_games' },
    'Utilization': { num: 'raw_played_mins', den: 'raw_floor_mins' },
    'Core Utilization': { num: 'raw_core_played_mins', den: 'raw_core_floor_mins' },
};

export const FIXED_AREAS = [
    'MainFloor', 
    'HighLimit', 
    'VIP'
];

export const getThresholds = (kpi, selectedAreas = []) => {
    let scenario = 'DEFAULT';
    
    if (selectedAreas && selectedAreas.length > 0) {
        const hasMass = selectedAreas.includes('MainFloor') || selectedAreas.includes('Mass');
        const hasPremium = selectedAreas.includes('HighLimit') || selectedAreas.includes('VIP');
        
        if (hasMass && !hasPremium) {
            scenario = 'MASS';
        } else if (!hasMass && hasPremium) {
            scenario = 'PREMIUM';
        }
    }

    if (scenario === 'MASS' && MASS_THRESHOLDS[kpi]) {
        return MASS_THRESHOLDS[kpi];
    } else if (scenario === 'PREMIUM' && PREMIUM_THRESHOLDS[kpi]) {
        return PREMIUM_THRESHOLDS[kpi];
    }

    return THRESHOLDS[kpi] || [];
};
