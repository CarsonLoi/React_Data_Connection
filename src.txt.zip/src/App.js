import React, { useState, useEffect } from 'react';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import { Box, Typography, Divider, Stack } from '@mui/material';
import './App.css';

// Data & Constants
import rawConfig from './data/config.json';
import rawDailyData from './data/slot_heatmap_data.json';
import rawHourlyData from './data/slot_hourly_data.json';
import { DAILY_KPI_LIST, HOURLY_KPI_LIST } from './constants/heatmapConstants';

// Hooks & Components
import { useHeatmapData } from './hooks/useHeatmapData';
import MultiSelectSlicer from './components/Slicers/MultiSelectSlicer';
import Switcher from './components/Slicers/Switcher';
import KPISelector from './components/Slicers/KPISelector';
import DateSelector from './components/Slicers/DateSelector';
import ScatterHeatmap from './components/Charts/ScatterHeatmap';
import PerformanceLegend from './components/Tables/PerformanceLegend';
import TrendCharts from './components/Charts/TrendCharts';


const darkTheme = createTheme({
  palette: {
    mode: 'dark',
    background: {
      default: '#1a1b26',
      paper: '#1e2030',
    },
    primary: {
      main: '#7aa2f7',
    },
  },
  typography: {
    fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
  },
});

function App() {
  // State for Filters
  const [selectedKPI, setSelectedKPI] = useState('Gametype');
  const [selectedSwitcher, setSelectedSwitcher] = useState('Avg');
  const [selectedArea, setSelectedArea] = useState([]);
  const [selectedManufacturer, setSelectedManufacturer] = useState([]);
  const [selectedGame, setSelectedGame] = useState([]);
  const [selectedLink, setSelectedLink] = useState([]);
  const [selectedDow, setSelectedDow] = useState([]);
  const [selectedStart, setSelectedStart] = useState('');
  const [selectedEnd, setSelectedEnd] = useState('');
  const [currentHour, setCurrentHour] = useState(0);
  const [selectedLocations, setSelectedLocations] = useState([]);
  const [selectedRefKPI, setSelectedRefKPI] = useState('None');

  // Update selectedKPI if it is not available in the new mode's KPI list
  useEffect(() => {
    const activeList = selectedSwitcher === '24-hr' ? HOURLY_KPI_LIST : DAILY_KPI_LIST;
    if (!activeList.includes(selectedKPI)) {
      setSelectedKPI('Gametype');
    }
  }, [selectedSwitcher, selectedKPI]);

  // Use the custom Data Hook
  const {
    dateRange,
    filterOptions,
    scatterData,
    timelineData,
    brushedScatterData,
    brushedTimelineData,
    processedTotals,
    dailyTrend,
    hourlyTrend
  } = useHeatmapData(
    rawDailyData, 
    rawHourlyData, 
    rawConfig, 
    {
      selectedStart,
      selectedEnd,
      selectedArea,
      selectedManufacturer,
      selectedGame,
      selectedLink,
      selectedDow,
      selectedSwitcher,
      selectedLocations
    }
  );

  // For the ranking chart, we want to always show all units that match the slicers,
  // not just the brushed ones.
  const activeScatterData = React.useMemo(() => scatterData ? scatterData.filter(d => !d.isFilteredOut) : [], [scatterData]);

  // Initialize dates once data is loaded
  useEffect(() => {
    if (dateRange.available.length > 0 && !selectedStart) {
      setSelectedEnd(dateRange.max);
      const start = new Date(dateRange.max);
      start.setDate(start.getDate() - 13); // 13 days back + max_date = 14 days window
      const dateStr = start.toISOString().split('T')[0];
      setSelectedStart(dateStr < dateRange.min ? dateRange.min : dateStr);
    }
  }, [dateRange, selectedStart]);

  return (
    <ThemeProvider theme={darkTheme}>
      <Box className="App" sx={{ minHeight: '100vh', bgcolor: '#1a1b26' }}>
        <header className="dashboard-header" style={{ 
            display: 'flex', 
            justifyContent: 'space-between', 
            alignItems: 'center',
            padding: '20px 40px',
            background: 'linear-gradient(180deg, rgba(30,32,48,0.9) 0%, rgba(30,32,48,0.4) 100%)',
            borderBottom: '1px solid rgba(255,255,255,0.05)'
        }}>
          <Box>
            <Typography variant="h5" sx={{ fontWeight: 700, color: '#fff', letterSpacing: 2 }}>
              CASINO SLOTS
            </Typography>
            <Typography variant="caption" sx={{ color: '#7aa2f7', letterSpacing: 3, fontWeight: 500 }}>
              PERFORMANCE HEATMAP DASHBOARD
            </Typography>
          </Box>
          <Box sx={{ textAlign: 'right' }}>
            <Typography variant="caption" sx={{ display: 'block', color: 'rgba(255,255,255,0.4)', fontWeight: 500 }}>
              ANALYSIS PERIOD
            </Typography>
            <Typography variant="body2" sx={{ color: '#fff', fontWeight: 600 }}>
              {selectedStart} — {selectedEnd}
            </Typography>
          </Box>
        </header>

        {/* TOP SLICER BAR - HORIZONTAL */}
        <Box className="slicer-container" sx={{ 
            display: 'flex',
            alignItems: 'center', 
            justifyContent: 'flex-start',
            p: 2,
            bgcolor: 'rgba(30,32,48,0.4)',
            backdropFilter: 'blur(10px)',
            borderBottom: '1px solid rgba(255,255,255,0.05)'
        }}>
          <Switcher 
            options={['Avg', '24-hr']} 
            value={selectedSwitcher} 
            onChange={setSelectedSwitcher} 
          />
          <Divider orientation="vertical" flexItem sx={{ mx: 2, borderColor: 'rgba(255,255,255,0.1)' }} />
          <MultiSelectSlicer 
            label="Area" 
            options={filterOptions.areas} 
            selected={selectedArea} 
            onChange={setSelectedArea} 
          />
          <MultiSelectSlicer 
            label="Manufacturer" 
            options={filterOptions.manufacturers} 
            selected={selectedManufacturer} 
            onChange={setSelectedManufacturer} 
          />
          <MultiSelectSlicer 
            label="Game Type" 
            options={filterOptions.games} 
            selected={selectedGame} 
            onChange={setSelectedGame} 
          />
          <MultiSelectSlicer 
            label="Link" 
            options={filterOptions.links} 
            selected={selectedLink} 
            onChange={setSelectedLink} 
          />
          <MultiSelectSlicer 
            label="Day of Week" 
            options={filterOptions.dows} 
            selected={selectedDow} 
            onChange={setSelectedDow} 
          />
          <Divider orientation="vertical" flexItem sx={{ mx: 2, borderColor: 'rgba(255,255,255,0.1)' }} />
          <DateSelector 
            start={selectedStart} 
            end={selectedEnd} 
            onStartChange={setSelectedStart} 
            onEndChange={setSelectedEnd}
            min={dateRange.min}
            max={dateRange.max}
          />
          <Divider orientation="vertical" flexItem sx={{ mx: 2, borderColor: 'rgba(255,255,255,0.1)' }} />
          <KPISelector 
            value={selectedKPI} 
            options={selectedSwitcher === '24-hr' ? HOURLY_KPI_LIST : DAILY_KPI_LIST} 
            onChange={setSelectedKPI} 
          />
          <KPISelector 
            label="Reference"
            value={selectedRefKPI} 
            options={['None', ...(selectedSwitcher === '24-hr' ? HOURLY_KPI_LIST : DAILY_KPI_LIST)]} 
            onChange={setSelectedRefKPI} 
          />

        </Box>

        {/* MAIN VISUALIZATION AREA */}
        <Box className="content-row" sx={{ display: 'flex', px: 4, pb: 4, gap: 4, flex: 1, overflow: 'hidden' }}>
          
          {/* COLUMN 1: HEATMAP (LEFT) */}
          <Box className="heatmap-wrapper" sx={{ 
              flex: 1, 
              display: 'flex', 
              flexDirection: 'column',
              bgcolor: 'rgba(10,10,12,0.3)',
              p: 2,
              borderRadius: '16px',
              border: '1px solid rgba(255,255,255,0.02)',
              overflow: 'hidden'
          }}>
            <ScatterHeatmap 
              data={scatterData} 
              timelineData={timelineData}
              selectedKPI={selectedKPI} 
              backgroundImageUrl="/assets/layout.png" 
              isTimeline={selectedSwitcher === '24-hr'}
              currentIndex={currentHour}
              onTimelineChange={setCurrentHour}
              onBrush={setSelectedLocations}
              selectedLocations={selectedLocations}
              selectedAreas={selectedArea}
            />
          </Box>
          
          {/* COLUMN 2: LEGEND & SUMMARY (MIDDLE) */}
          <Box className="legend-wrapper" sx={{ flex: 0.6, minWidth: '300px', display: 'flex', flexDirection: 'column', gap: 3 }}>
            <Box sx={{ 
                p: 2.5, 
                bgcolor: 'rgba(30,32,48,0.6)', 
                borderRadius: '16px', 
                border: '1px solid rgba(255,255,255,0.05)',
                boxShadow: '0 8px 32px rgba(0,0,0,0.3)',
                flex: 1,
                display: 'flex',
                flexDirection: 'column',
                overflow: 'hidden'
            }}>
              <Typography variant="subtitle2" sx={{ mb: 2, color: '#7aa2f7', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 1.5, fontSize: '0.75rem' }}>
                Area Performance Breakdown {selectedLocations.length > 0 && `(Selected: ${selectedLocations.length} Units)`}
              </Typography>
              <PerformanceLegend 
                data={selectedSwitcher === '24-hr' && brushedTimelineData && brushedTimelineData.length > 0 ? (brushedTimelineData[currentHour] || []) : brushedScatterData} 
                selectedKPI={selectedKPI} 
                selectedAreas={selectedArea}
              />
            </Box>

          </Box>

          {/* COLUMN 3: TREND REFERENCE (RIGHT) */}
          <Box className="trends-wrapper" sx={{ flex: 1, minWidth: '400px', display: 'flex', flexDirection: 'column' }}>
            {selectedRefKPI === 'None' ? (
                <TrendCharts 
                    data={selectedSwitcher === '24-hr' ? hourlyTrend : dailyTrend} 
                    isHourly={selectedSwitcher === '24-hr'}
                    scatterData={activeScatterData}
                    selectedLocations={selectedLocations}
                    onRankingSelection={setSelectedLocations}
                />
            ) : (
                <Box sx={{ 
                    flex: 1, 
                    display: 'flex', 
                    flexDirection: 'column',
                    bgcolor: 'rgba(10,10,12,0.3)',
                    p: 2,
                    borderRadius: '16px',
                    border: '1px solid rgba(255,255,255,0.02)',
                    overflow: 'hidden'
                }}>
                    <Typography variant="subtitle2" sx={{ mb: 1, color: '#7aa2f7', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 1.5, fontSize: '0.75rem' }}>
                        Reference View: {selectedRefKPI}
                    </Typography>
                    <ScatterHeatmap 
                        data={scatterData} 
                        timelineData={timelineData}
                        selectedKPI={selectedRefKPI} 
                        backgroundImageUrl="/assets/layout.png" 
                        isTimeline={selectedSwitcher === '24-hr'}
                        currentIndex={currentHour}
                        onTimelineChange={setCurrentHour}
                        onBrush={setSelectedLocations}
                        selectedLocations={selectedLocations}
                    />
                </Box>
            )}
          </Box>

        </Box>
      </Box>
    </ThemeProvider>
  );
}


export default App;
