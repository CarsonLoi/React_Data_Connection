import { useState, useMemo, useEffect } from 'react';

/**
 * Custom hook to encapsulate all data filtering and aggregation logic.
 */
export const useHeatmapData = (rawData, hourlyData, configData, filters) => {
    const {
        selectedStart,
        selectedEnd,
        selectedArea,
        selectedManufacturer,
        selectedGame,
        selectedLink,
        selectedDow,
        selectedSwitcher, // 'Avg' or '24-hr'
        selectedLocations = [] // NEW: IDs of units selected via brush
    } = filters;

    // 1. Initial Data Prep
    const dateRange = useMemo(() => {
        if (!rawData || rawData.length === 0) return { available: [], min: '', max: '' };
        const dates = [...new Set(rawData.map(item => item.date))].sort((a, b) => new Date(a) - new Date(b));
        return {
            available: dates,
            min: dates[0],
            max: dates[dates.length - 1]
        };
    }, [rawData]);

    // 2. Dynamic Filter Options
    const filterOptions = useMemo(() => {
        const data = selectedSwitcher === 'Avg' ? rawData : hourlyData;
        if (!data || data.length === 0) return { areas: [], manufacturers: [], games: [], dows: ['WD', 'WE'] };

        return {
            areas: [...new Set(data.map(item => item.area))].sort(),
            manufacturers: [...new Set(data.map(item => item.manufacturer))].sort(),
            games: [...new Set(data.map(item => item.gametype))].sort(),
            links: [...new Set(data.map(item => item.link || 'None'))].sort(),
            dows: ['WD', 'WE']
        };
    }, [rawData, hourlyData, selectedSwitcher]);

    // 3. Main Filtering Engine (Slicer Filters)
    const dateFilteredData = useMemo(() => {
        const data = selectedSwitcher === 'Avg' ? rawData : hourlyData;
        if (!data || data.length === 0) return [];
        return data.filter(d => {
            const matchDate = (!selectedStart || d.date >= selectedStart) && (!selectedEnd || d.date <= selectedEnd);
            return matchDate;
        });
    }, [rawData, hourlyData, selectedSwitcher, selectedStart, selectedEnd]);

    const filteredData = useMemo(() => {
        return dateFilteredData.filter(d => {
            const matchArea = selectedArea.length === 0 || selectedArea.includes(d.area);
            const matchManufacturer = selectedManufacturer.length === 0 || selectedManufacturer.includes(d.manufacturer);
            const matchGame = selectedGame.length === 0 || selectedGame.includes(d.gametype);
            const matchLink = selectedLink.length === 0 || selectedLink.includes(d.link || 'None');
            const matchDow = selectedDow.length === 0 || selectedDow.includes(d.dow);
            return matchArea && matchManufacturer && matchGame && matchLink && matchDow;
        });
    }, [dateFilteredData, selectedArea, selectedManufacturer, selectedGame, selectedLink, selectedDow]);

    // 3.1 Brush Filtering Engine (Subset of filteredData)
    const brushedData = useMemo(() => {
        if (selectedLocations.length === 0) return filteredData;
        return filteredData.filter(d => selectedLocations.includes(`${d.location}_${d.asset}`));
    }, [filteredData, selectedLocations]);

    // Helper: Mode calculation for Denomination
    const getModeDenom = (arr) => {
        let max = -1; let mode = 0;
        if (!arr) return 0;
        Object.entries(arr).forEach(([k, v]) => { if (v > max) { max = v; mode = k; } });
        return mode;
    };

    // 4. Aggregation & Builder Engine - CHART BASE DATA
    // This only depends on filteredData (slicer state), not on selection state (brush).
    // This ensures ScatterHeatmap doesn't re-render its internal chart instance when brushing.
    const { scatterData, timelineData } = useMemo(() => {
        if (!configData) {
            return { scatterData: [], timelineData: [] };
        }

        const activeConfig = configData.filter(conf => {
            return (!selectedEnd || (selectedEnd >= conf.startdate && selectedEnd <= conf.enddate)) && conf.is_Active === 1;
        });

        const activeLocations = new Set(activeConfig.map(c => `${c.location}_${c.asset}`));

        if (selectedSwitcher === 'Avg') {
            const scatterResult = {};
            filteredData.forEach(value => {
                const key = `${value.location}_${value.asset}`;
                if (!activeLocations.has(key)) return;
                if (!scatterResult[key]) {
                    scatterResult[key] = {
                        location: value.location, asset: value.asset, link: value.link, turnover: 0, win: 0, theo: 0, rated_theo: 0, games: 0,
                        played_mins: 0, floor_mins: 0, core_played_mins: 0, core_floor_mins: 0, mday: 0,
                        denom_array: {}
                    };
                }
                const res = scatterResult[key];
                res.turnover += value.turnover || 0;
                res.win += value.win || 0;
                res.theo += value.theo || 0;
                res.rated_theo += value.rated_theo || 0;
                res.games += value.games || 0;
                res.played_mins += value.played_mins || 0;
                res.floor_mins += value.floor_mins || 0;
                res.core_played_mins += value.core_played_mins || 0;
                res.core_floor_mins += value.core_floor_mins || 0;
                res.mday += value.mday || 0;
                if (value.denom_array) {
                    for (const denom in value.denom_array) res.denom_array[denom] = (res.denom_array[denom] || 0) + value.denom_array[denom];
                }
            });

            const finalScatter = activeConfig.map(row => {
                const stats = scatterResult[`${row.location}_${row.asset}`];
                
                // Determine if this specific unit from config matches the current slicers
                const matchArea = selectedArea.length === 0 || selectedArea.includes(row.area);
                const matchManufacturer = selectedManufacturer.length === 0 || selectedManufacturer.includes(row.manufacturer);
                const matchGame = selectedGame.length === 0 || selectedGame.includes(row.game);
                // For link and dow, we might not have them in config, but if stats exist, they match.
                // If stats don't exist, it's filtered out.
                const isMatched = !!stats;

                return {
                    ...row,
                    link: stats ? stats.link : 'None',
                    turnover: isMatched && stats.mday > 0 ? stats.turnover / stats.mday : null,
                    win: isMatched && stats.mday > 0 ? stats.win / stats.mday : null,
                    theo: isMatched && stats.mday > 0 ? stats.theo / stats.mday : null,
                    rated_theo: isMatched && stats.mday > 0 ? stats.rated_theo / stats.mday : null,
                    pulls: isMatched && stats.mday > 0 ? stats.games / stats.mday : null,
                    avgBet: isMatched && stats.games > 0 ? stats.turnover / stats.games : null,
                    utilization: isMatched && stats.floor_mins > 0 ? stats.played_mins / stats.floor_mins : null,
                    coreUtilization: isMatched && stats.core_floor_mins > 0 ? stats.core_played_mins / stats.core_floor_mins : null,
                    denomination: isMatched && stats.mday > 0 ? parseFloat(getModeDenom(stats.denom_array)) : null,
                    raw_turnover: isMatched ? stats.turnover : 0,
                    raw_win: isMatched ? stats.win : 0,
                    raw_theo: isMatched ? stats.theo : 0,
                    raw_rated_theo: isMatched ? stats.rated_theo : 0,
                    raw_games: isMatched ? stats.games : 0,
                    raw_played_mins: isMatched ? stats.played_mins : 0,
                    raw_floor_mins: isMatched ? stats.floor_mins : 0,
                    raw_core_played_mins: isMatched ? stats.core_played_mins : 0,
                    raw_core_floor_mins: isMatched ? stats.core_floor_mins : 0,
                    raw_mday: isMatched ? stats.mday : 0,
                    isFilteredOut: !isMatched
                };
            });

            return { scatterData: finalScatter, timelineData: [] };

        } else {
            const buildHourlyResult = (dataSource) => {
                const hrRes = Array.from({ length: 24 }, () => ({}));
                dataSource.forEach(value => {
                    const h = value.hour;
                    const locKey = `${value.location}_${value.asset}`;
                    if (!activeLocations.has(locKey)) return;
                    if (!hrRes[h][locKey]) {
                        hrRes[h][locKey] = {
                            location: value.location, asset: value.asset, link: value.link, turnover: 0, win: 0, theo: 0, rated_theo: 0, games: 0,
                            played_mins: 0, floor_mins: 0, core_played_mins: 0, core_floor_mins: 0, mday: 0,
                            denom_array: {}
                        };
                    }
                    const res = hrRes[h][locKey];
                    res.turnover += value.turnover || 0;
                    res.win += value.win || 0;
                    res.theo += value.theo || 0;
                    res.rated_theo += value.rated_theo || 0;
                    res.games += value.games || 0;
                    res.played_mins += value.played_mins || 0;
                    res.floor_mins += value.floor_mins || 0;
                    res.core_played_mins += value.core_played_mins || 0;
                    res.core_floor_mins += value.core_floor_mins || 0;
                    res.mday += value.mday || 0;
                    if (value.denom_array) {
                        for (const d in value.denom_array) res.denom_array[d] = (res.denom_array[d] || 0) + value.denom_array[d];
                    }
                });
                return hrRes;
            };

            const fullHourlyResult = buildHourlyResult(filteredData);
            const GAMING_HOUR_SEQUENCE = [6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 0, 1, 2, 3, 4, 5];

            const buildTimeline = (hrRes) => {
                return GAMING_HOUR_SEQUENCE.map(h => {
                    const hourGroup = hrRes[h];
                    return activeConfig.map(row => {
                        const stats = hourGroup[`${row.location}_${row.asset}`];
                        const isMatched = !!stats;

                        return {
                            ...row,
                            hour: h,
                            link: stats ? stats.link : 'None',
                            turnover: isMatched && stats.mday > 0 ? stats.turnover / stats.mday : null,
                            win: isMatched && stats.mday > 0 ? stats.win / stats.mday : null,
                            theo: isMatched && stats.mday > 0 ? stats.theo / stats.mday : null,
                            rated_theo: isMatched && stats.mday > 0 ? stats.rated_theo / stats.mday : null,
                            pulls: isMatched && stats.mday > 0 ? stats.games / stats.mday : null,
                            avgBet: isMatched && stats.games > 0 ? stats.turnover / stats.games : null,
                            utilization: isMatched && stats.floor_mins > 0 ? stats.played_mins / stats.floor_mins : null,
                            coreUtilization: isMatched && stats.core_floor_mins > 0 ? stats.core_played_mins / stats.core_floor_mins : null,
                            denomination: isMatched && stats.mday > 0 ? parseFloat(getModeDenom(stats.denom_array)) : null,
                            raw_turnover: isMatched ? stats.turnover : 0,
                            raw_win: isMatched ? stats.win : 0,
                            raw_theo: isMatched ? stats.theo : 0,
                            raw_rated_theo: isMatched ? stats.rated_theo : 0,
                            raw_games: isMatched ? stats.games : 0,
                            raw_played_mins: isMatched ? stats.played_mins : 0,
                            raw_floor_mins: isMatched ? stats.floor_mins : 0,
                            raw_core_played_mins: isMatched ? stats.core_played_mins : 0,
                            raw_core_floor_mins: isMatched ? stats.core_floor_mins : 0,
                            raw_mday: isMatched ? stats.mday : 0,
                            isFilteredOut: !isMatched
                        };
                    });
                });
            };

            const fullTimeline = buildTimeline(fullHourlyResult);

            return {
                scatterData: fullTimeline[0] || [],
                timelineData: fullTimeline
            };
        }
    }, [configData, filteredData, selectedSwitcher, selectedEnd]);

    // 4.1 Aggregation & Builder Engine - BRUSHED RESULTS
    // This depends on brushedData (selection state).
    const { brushedScatterData, brushedTimelineData, processedTotals } = useMemo(() => {
        if (!configData || brushedData.length === 0) {
            return { brushedScatterData: [], brushedTimelineData: [], processedTotals: {} };
        }

        const activeConfig = configData.filter(conf => {
            return (!selectedEnd || (selectedEnd >= conf.startdate && selectedEnd <= conf.enddate)) && conf.is_Active === 1;
        });

        const activeLocations = new Set(activeConfig.map(c => `${c.location}_${c.asset}`));

        if (selectedSwitcher === 'Avg') {
            const totalsResult = {};
            brushedData.forEach(value => {
                const key = `${value.location}_${value.asset}`;
                if (!activeLocations.has(key)) return;

                if (!totalsResult[key]) {
                    totalsResult[key] = {
                        location: value.location, asset: value.asset, link: value.link, turnover: 0, win: 0, theo: 0, rated_theo: 0, games: 0,
                        played_mins: 0, floor_mins: 0, core_played_mins: 0, core_floor_mins: 0, mday: 0,
                        denom_array: {}
                    };
                }
                const res = totalsResult[key];
                res.turnover += value.turnover || 0;
                res.win += value.win || 0;
                res.theo += value.theo || 0;
                res.rated_theo += value.rated_theo || 0;
                res.games += value.games || 0;
                res.played_mins += value.played_mins || 0;
                res.floor_mins += value.floor_mins || 0;
                res.core_played_mins += value.core_played_mins || 0;
                res.core_floor_mins += value.core_floor_mins || 0;
                res.mday += value.mday || 0;
                if (value.denom_array) {
                    for (const denom in value.denom_array) res.denom_array[denom] = (res.denom_array[denom] || 0) + value.denom_array[denom];
                }
            });

            const finalBrushedData = activeConfig.map(row => {
                const stats = totalsResult[`${row.location}_${row.asset}`];
                if (!stats) return null;
                return {
                    ...row,
                    link: stats.link,
                    turnover: stats.mday > 0 ? stats.turnover / stats.mday : 0,
                    win: stats.mday > 0 ? stats.win / stats.mday : 0,
                    theo: stats.mday > 0 ? stats.theo / stats.mday : 0,
                    rated_theo: stats.mday > 0 ? stats.rated_theo / stats.mday : 0,
                    pulls: stats.mday > 0 ? stats.games / stats.mday : 0,
                    avgBet: stats.games > 0 ? stats.turnover / stats.games : 0,
                    utilization: stats.floor_mins > 0 ? stats.played_mins / stats.floor_mins : 0,
                    coreUtilization: stats.core_floor_mins > 0 ? stats.core_played_mins / stats.core_floor_mins : 0,
                    denomination: stats.mday > 0 ? parseFloat(getModeDenom(stats.denom_array)) : 0,
                    raw_turnover: stats.turnover,
                    raw_win: stats.win,
                    raw_theo: stats.theo,
                    raw_rated_theo: stats.rated_theo,
                    raw_games: stats.games,
                    raw_played_mins: stats.played_mins,
                    raw_floor_mins: stats.floor_mins,
                    raw_core_played_mins: stats.core_played_mins,
                    raw_core_floor_mins: stats.core_floor_mins,
                    raw_mday: stats.mday
                };
            }).filter(d => d !== null);

            return { brushedScatterData: finalBrushedData, brushedTimelineData: [], processedTotals: totalsResult };

        } else {
            const buildHourlyResult = (dataSource) => {
                const hrRes = Array.from({ length: 24 }, () => ({}));
                dataSource.forEach(value => {
                    const h = value.hour;
                    const locKey = `${value.location}_${value.asset}`;
                    if (!activeLocations.has(locKey)) return;
                    if (!hrRes[h][locKey]) {
                        hrRes[h][locKey] = {
                            location: value.location, asset: value.asset, link: value.link, turnover: 0, win: 0, theo: 0, rated_theo: 0, games: 0,
                            played_mins: 0, floor_mins: 0, core_played_mins: 0, core_floor_mins: 0, mday: 0,
                            denom_array: {}
                        };
                    }
                    const res = hrRes[h][locKey];
                    res.turnover += value.turnover || 0;
                    res.win += value.win || 0;
                    res.theo += value.theo || 0;
                    res.rated_theo += value.rated_theo || 0;
                    res.games += value.games || 0;
                    res.played_mins += value.played_mins || 0;
                    res.floor_mins += value.floor_mins || 0;
                    res.core_played_mins += value.core_played_mins || 0;
                    res.core_floor_mins += value.core_floor_mins || 0;
                    res.mday += value.mday || 0;
                    if (value.denom_array) {
                        for (const d in value.denom_array) res.denom_array[d] = (res.denom_array[d] || 0) + value.denom_array[d];
                    }
                });
                return hrRes;
            };

            const brushedHourlyResult = buildHourlyResult(brushedData);
            const GAMING_HOUR_SEQUENCE = [6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 0, 1, 2, 3, 4, 5];

            const buildTimeline = (hrRes) => {
                return GAMING_HOUR_SEQUENCE.map(h => {
                    const hourGroup = hrRes[h];
                    return activeConfig.map(row => {
                        const stats = hourGroup[`${row.location}_${row.asset}`];
                        if (!stats) return null;
                        return {
                            ...row,
                            hour: h,
                            link: stats.link,
                            turnover: stats.mday > 0 ? stats.turnover / stats.mday : 0,
                            win: stats.mday > 0 ? stats.win / stats.mday : 0,
                            theo: stats.mday > 0 ? stats.theo / stats.mday : 0,
                            rated_theo: stats.mday > 0 ? stats.rated_theo / stats.mday : 0,
                            pulls: stats.mday > 0 ? stats.games / stats.mday : 0,
                            avgBet: stats.games > 0 ? stats.turnover / stats.games : 0,
                            utilization: stats.floor_mins > 0 ? stats.played_mins / stats.floor_mins : 0,
                            coreUtilization: stats.core_floor_mins > 0 ? stats.core_played_mins / stats.core_floor_mins : 0,
                            denomination: stats.mday > 0 ? parseFloat(getModeDenom(stats.denom_array)) : 0,
                            raw_turnover: stats.turnover,
                            raw_win: stats.win,
                            raw_theo: stats.theo,
                            raw_rated_theo: stats.rated_theo,
                            raw_games: stats.games,
                            raw_played_mins: stats.played_mins,
                            raw_floor_mins: stats.floor_mins,
                            raw_core_played_mins: stats.core_played_mins,
                            raw_core_floor_mins: stats.core_floor_mins,
                            raw_mday: stats.mday
                        };
                    }).filter(d => d !== null);
                });
            };

            const brushedTimeline = buildTimeline(brushedHourlyResult);

            return {
                brushedScatterData: brushedTimeline[0] || [],
                brushedTimelineData: brushedTimeline,
                processedTotals: brushedHourlyResult
            };
        }
    }, [configData, brushedData, selectedSwitcher, selectedEnd]);

    // 5. Trend Aggregation (Daily & Hourly) - Use brushedData
    const { dailyTrend, hourlyTrend } = useMemo(() => {
        if (!brushedData || brushedData.length === 0) {
            return { dailyTrend: [], hourlyTrend: [] };
        }

        const dailyMap = {};
        const hourlyMap = Array.from({ length: 24 }, (_, i) => ({
            hour: i, turnover: 0, win: 0, theo: 0, rated_theo: 0, games: 0, 
            played_mins: 0, floor_mins: 0, core_played_mins: 0, core_floor_mins: 0, mday: 0
        }));

        brushedData.forEach(d => {
            // Daily Aggregation
            if (!dailyMap[d.date]) {
                dailyMap[d.date] = { 
                    date: d.date, turnover: 0, win: 0, theo: 0, rated_theo: 0, games: 0, 
                    played_mins: 0, floor_mins: 0, core_played_mins: 0, core_floor_mins: 0, count: 0 
                };
            }
            dailyMap[d.date].turnover += d.turnover || 0;
            dailyMap[d.date].win += d.win || 0;
            dailyMap[d.date].theo += d.theo || 0;
            dailyMap[d.date].rated_theo += d.rated_theo || 0;
            dailyMap[d.date].games += d.games || 0;
            dailyMap[d.date].played_mins += d.played_mins || 0;
            dailyMap[d.date].floor_mins += d.floor_mins || 0;
            dailyMap[d.date].core_played_mins += d.core_played_mins || 0;
            dailyMap[d.date].core_floor_mins += d.core_floor_mins || 0;
            dailyMap[d.date].count += 1;

            // Hourly Aggregation
            if (d.hour !== undefined) {
                const hr = hourlyMap[d.hour];
                hr.turnover += d.turnover || 0;
                hr.win += d.win || 0;
                hr.theo += d.theo || 0;
                hr.rated_theo += d.rated_theo || 0;
                hr.games += d.games || 0;
                hr.played_mins += d.played_mins || 0;
                hr.floor_mins += d.floor_mins || 0;
                hr.core_played_mins += d.core_played_mins || 0;
                hr.core_floor_mins += d.core_floor_mins || 0;
                hr.mday += d.mday || 0;
            }
        });

        const daily = Object.values(dailyMap)
            .sort((a, b) => new Date(a.date) - new Date(b.date))
            .map(d => ({
                label: d.date,
                turnover: d.turnover,
                win: d.win,
                theo: d.theo,
                rated_theo: d.rated_theo,
                avgBet: d.games > 0 ? d.turnover / d.games : 0,
                pulls: d.games,
                utilization: d.floor_mins > 0 ? d.played_mins / d.floor_mins : 0,
                coreUtilization: d.core_floor_mins > 0 ? d.core_played_mins / d.core_floor_mins : 0
            }));

        const GAMING_HOUR_SEQUENCE = [6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 0, 1, 2, 3, 4, 5];
        const hourly = GAMING_HOUR_SEQUENCE.map(h => {
            const dataH = hourlyMap[h];
            return {
                label: `${h.toString().padStart(2, '0')}:00`,
                turnover: dataH.mday > 0 ? dataH.turnover / dataH.mday : dataH.turnover,
                win: dataH.mday > 0 ? dataH.win / dataH.mday : dataH.win,
                theo: dataH.mday > 0 ? dataH.theo / dataH.mday : dataH.theo,
                rated_theo: dataH.mday > 0 ? dataH.rated_theo / dataH.mday : dataH.rated_theo,
                avgBet: dataH.games > 0 ? dataH.turnover / dataH.games : 0,
                pulls: dataH.mday > 0 ? dataH.games / dataH.mday : dataH.games,
                utilization: dataH.floor_mins > 0 ? dataH.played_mins / dataH.floor_mins : 0,
                coreUtilization: dataH.core_floor_mins > 0 ? dataH.core_played_mins / dataH.core_floor_mins : 0
            };
        });

        return { dailyTrend: daily, hourlyTrend: hourly };

    }, [brushedData]);

    return {
        dateRange,
        filterOptions,
        scatterData,
        timelineData,
        brushedScatterData,
        brushedTimelineData,
        processedTotals,
        dailyTrend,
        hourlyTrend,
        rawData
    };
};

