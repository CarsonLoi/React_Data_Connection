import React, { useMemo } from 'react';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography, Box } from '@mui/material';
import { THRESHOLDS, GAMETYPE_COLORS, MANUFACTURER_COLORS, LINK_COLORS, FIXED_AREAS, KPI_FIELD_MAP, KPI_RATIO_MAP, getThresholds } from '../../constants/heatmapConstants';

const PerformanceLegend = ({ data, selectedKPI, selectedAreas = [] }) => {

    const { tableRows, areaKeys, overallAverages, totalUnits, isCategorical } = useMemo(() => {
        if (!data || data.length === 0) return { tableRows: [], areaKeys: [], overallAverages: {}, totalUnits: {}, isCategorical: false };

        // 1. Filter out greyed-out units so they don't skew legend counts/averages
        const activeData = data.filter(d => !d.isFilteredOut);

        // 2. Use Fixed Areas for columns to ensure they always show
        const areaKeys = [...FIXED_AREAS];
        
        const valueField = KPI_FIELD_MAP[selectedKPI] || 'turnover';
        const isCategorical = selectedKPI === 'Gametype' || selectedKPI === 'Manufacturer' || selectedKPI === 'Link';
        const tableRows = [];

        if (isCategorical) {
            const colorMap = 
                selectedKPI === 'Gametype' ? GAMETYPE_COLORS : 
                selectedKPI === 'Manufacturer' ? MANUFACTURER_COLORS : 
                LINK_COLORS;
            Object.entries(colorMap).forEach(([key, color]) => {
                const row = { label: key, color: color, counts: {} };
                let hasData = false;
                areaKeys.forEach(area => {
                    const count = activeData.filter(d => d.area === area && d[valueField] === key).length;
                    row.counts[area] = count;
                    if (count > 0) hasData = true;
                });
                if (hasData) tableRows.push(row);
            });
        } else {
            const thresholds = getThresholds(selectedKPI, selectedAreas);
            thresholds.forEach(t => {
                const row = { label: t.label, color: t.color, counts: {} };
                areaKeys.forEach(area => {
                    row.counts[area] = activeData.filter(d => {
                        if (d.area !== area) return false;
                        const val = d[valueField] || 0;
                        if (t.gte !== undefined && val < t.gte) return false;
                        if (t.lt !== undefined && val >= t.lt) return false;
                        return true;
                    }).length;
                });
                tableRows.push(row);
            });
        }

        // Calculate Overall Average per Area for non-categorical KPIs
        const overallAverages = {};
        if (!isCategorical) {
            const ratioConfig = KPI_RATIO_MAP[selectedKPI];
            
            areaKeys.forEach(area => {
                const areaData = activeData.filter(d => d.area === area);
                if (areaData.length === 0) {
                    overallAverages[area] = 0;
                } else if (ratioConfig) {
                    // Correct Math: sum(A) / sum(B)
                    const totalNum = areaData.reduce((acc, d) => acc + (d[ratioConfig.num] || 0), 0);
                    const totalDen = areaData.reduce((acc, d) => acc + (d[ratioConfig.den] || 0), 0);
                    overallAverages[area] = totalDen > 0 ? totalNum / totalDen : 0;
                } else {
                    // Fallback for non-ratio KPIs (like Denomination mode)
                    const sum = areaData.reduce((acc, d) => acc + (d[valueField] || 0), 0);
                    overallAverages[area] = sum / areaData.length;
                }
            });
        }

        // Calculate Totals per Area
        const totalUnits = {};
        areaKeys.forEach(area => {
            totalUnits[area] = activeData.filter(d => d.area === area).length;
        });

        return { tableRows, areaKeys, overallAverages, totalUnits, isCategorical };

    }, [data, selectedKPI]);

    if (!data || data.length === 0) return <Typography variant="caption">No data available for selected period.</Typography>;

    const formatAverage = (val) => {
        if (selectedKPI === 'Utilization' || selectedKPI === 'Core Utilization') return (val * 100).toFixed(1) + '%';
        if (val > 1000) return (val / 1000).toFixed(1) + 'K';
        return val.toLocaleString(undefined, { maximumFractionDigits: 0 });
    };

    return (
        <TableContainer component={Box} sx={{ bgcolor: 'transparent', border: 'none', maxHeight: '650px', overflowY: 'auto' }}>
            <Table size="small" stickyHeader>
                <TableHead>
                    <TableRow>
                        <TableCell sx={{ color: 'rgba(255,255,255,0.5)', borderBottom: '1px solid rgba(255,255,255,0.05)', fontSize: '0.75rem', py: 1, bgcolor: 'rgba(30,32,48,1)', zIndex: 2 }}>
                            No. Units
                        </TableCell>
                        {areaKeys.map(area => (
                            <TableCell key={area} align="center" sx={{ color: 'rgba(255,255,255,0.5)', borderBottom: '1px solid rgba(255,255,255,0.05)', fontSize: '0.75rem', py: 1, bgcolor: 'rgba(30,32,48,1)', zIndex: 2 }}>
                                {area}
                            </TableCell>
                        ))}
                    </TableRow>
                </TableHead>
                <TableBody>
                    {tableRows.map((row, idx) => (
                        <TableRow key={idx} sx={{ '&:last-child td, &:last-child th': { border: 0 }, '&:hover': { bgcolor: 'rgba(255,255,255,0.02)' } }}>
                            <TableCell component="th" scope="row" sx={{ 
                                color: '#fff', 
                                borderBottom: '1px solid rgba(255,255,255,0.05)',
                                py: 0.5, px: 0.5, fontSize: '0.8rem', display: 'flex', alignItems: 'center', gap: 1
                            }}>
                                <Box sx={{ width: 12, height: 12, bgcolor: row.color, borderRadius: '2px', flexShrink: 0 }} />
                                {row.label}
                            </TableCell>
                            {areaKeys.map(area => (
                                <TableCell key={area} align="center" sx={{ 
                                    color: row.counts[area] === 0 ? 'rgba(255,255,255,0.2)' : '#fff', 
                                    borderBottom: '1px solid rgba(255,255,255,0.05)',
                                    py: 0.5, fontSize: '0.8rem'
                                }}>
                                    {row.counts[area] || '-'}
                                </TableCell>
                            ))}
                        </TableRow>
                    ))}

                    {/* Overall Average or Total row */}
                    <TableRow>
                        <TableCell component="th" scope="row" sx={{ 
                            color: '#7aa2f7', 
                            borderBottom: 'none', borderTop: '1px solid rgba(255,255,255,0.1)',
                            py: 1.5, px: 0.5, fontSize: '0.8rem', fontWeight: 600
                        }}>
                            {isCategorical ? 'Total Units' : 'Overall Avg'}
                        </TableCell>
                        {areaKeys.map(area => (
                            <TableCell key={area} align="center" sx={{ 
                                color: '#7aa2f7', 
                                borderBottom: 'none', borderTop: '1px solid rgba(255,255,255,0.1)',
                                py: 1.5, fontSize: '0.8rem', fontWeight: 600
                            }}>
                                {isCategorical ? totalUnits[area] : formatAverage(overallAverages[area])}
                            </TableCell>
                        ))}
                    </TableRow>
                </TableBody>
            </Table>
            
            <Box sx={{ mt: 2, pt: 2, borderTop: '1px dashed rgba(255,255,255,0.1)' }}>
                <Typography variant="caption" sx={{ color: 'rgba(122, 162, 247, 0.4)', fontStyle: 'italic', fontSize: '0.65rem', lineHeight: 1.2, display: 'block' }}>
                    * Figures represent active units per area falling into each performance tier.
                </Typography>
            </Box>
        </TableContainer>
    );
};

export default PerformanceLegend;

