import React, { useEffect, useRef } from 'react';
import * as echarts from 'echarts';
import { Box } from '@mui/material';
import { THRESHOLDS, SVG_PATHS, GAMETYPE_COLORS, MANUFACTURER_COLORS, LINK_COLORS, KPI_FIELD_MAP, getThresholds } from '../../constants/heatmapConstants';

const ScatterHeatmap = ({ data, timelineData, selectedKPI, backgroundImageUrl, isTimeline, currentIndex, onTimelineChange, onBrush, selectedLocations = [], selectedAreas = [] }) => {
    const chartRef = useRef(null);
    const chartInstance = useRef(null);
    const lastIndexRef = useRef(currentIndex);
    const internalBrushRef = useRef([]);

    // Update lastIndexRef when prop changes
    useEffect(() => {
        lastIndexRef.current = currentIndex;
    }, [currentIndex]);

    useEffect(() => {
        if (!chartRef.current) return;

        if (!chartInstance.current) {
            chartInstance.current = echarts.init(chartRef.current);
            
            // Listen for timeline changes to sync back to React
            chartInstance.current.on('timelinechanged', (e) => {
                const newIdx = e.currentIndex;
                if (lastIndexRef.current !== newIdx) {
                    lastIndexRef.current = newIdx;
                    onTimelineChange?.(newIdx);
                }
            });
        }

        const chart = chartInstance.current;
        const thresholds = getThresholds(selectedKPI, selectedAreas);
        const isCategorical = selectedKPI === 'Gametype' || selectedKPI === 'Manufacturer' || selectedKPI === 'Link';

        // Helper to map record to array for ECharts
        const mapRecord = (d) => {
            const svgPath = SVG_PATHS[d.game]?.path || '';
            const sizeX = SVG_PATHS[d.game]?.sizeX || 7;
            const sizeY = SVG_PATHS[d.game]?.sizeY || 7;
            
            let val = d.turnover;
            if (selectedKPI === 'GGR per unit per day') val = d.win;
            else if (selectedKPI === 'Theo per unit per day') val = d.theo;
            else if (selectedKPI === 'Utilization') val = d.utilization;
            else if (selectedKPI === 'Denomination') val = d.denomination;
            else if (selectedKPI === 'Gametype') val = d.game;
            else if (selectedKPI === 'Manufacturer') val = d.manufacturer;
            else if (selectedKPI === 'Link') val = d.link;
            
            // If unit is filtered out by slicers, force value to null to trigger 'outOfRange' grey color
            if (d.isFilteredOut) val = null;

            const isSelected = selectedLocations.length === 0 || selectedLocations.includes(`${d.location}_${d.asset}`);

            return {
                value: [
                    d.x, d.y, d.rotation, d.game, `path://${svgPath}`, sizeX, sizeY, d.location, val,
                    d.turnover, d.win, d.theo, d.utilization, d.denomination, d.manufacturer,
                    isSelected ? 1 : 0, d.asset, d.link
                ],
                itemStyle: {
                    opacity: isSelected ? undefined : 0.1,
                    borderWidth: isSelected ? 0.5 : 0
                }
            };
        };

        const baseOption = {
            animation: false,
            backgroundColor: 'transparent',

            grid: {
                show: true,
                left: 0, right: 0, top: 0, bottom: 0,
                borderWidth: 0,
                backgroundColor: {
                    image: backgroundImageUrl,
                    repeat: 'no-repeat'
                }
            },
            xAxis: { min: 0, max: 1050, splitLine: { show: false }, axisLabel: { show: false }, axisTick: { show: false }, axisLine: { show: false } },
            yAxis: { min: 0, max: 1107, splitLine: { show: false }, axisLabel: { show: false }, axisTick: { show: false }, axisLine: { show: false } },
            tooltip: {
                backgroundColor: 'rgba(20, 21, 33, 0.95)',
                borderColor: 'rgba(255, 255, 255, 0.1)',
                borderWidth: 1,
                padding: 0,
                textStyle: { color: '#fff' },
                formatter: (params) => {
                    const v = params.value;
                    if (!v || !Array.isArray(v) || v.length < 14) return '';
                    
                    const turnover = typeof v[9] === 'number' ? v[9] : 0;
                    const win = typeof v[10] === 'number' ? v[10] : 0;
                    const theo = typeof v[11] === 'number' ? v[11] : 0;
                    const util = typeof v[12] === 'number' ? v[12] : 0;
                    const denom = v[13] || 0;
                    const manufacturer = v[14] || 'Unknown';
                    const location = v[7] || 'N/A';
                    const game = v[3] || 'N/A';
                    const asset = v[16] || 'N/A';
                    const link = v[17] || 'None';

                    const formatMoney = (val) => {
                        const sign = val < 0 ? '-' : '';
                        return `${sign}$${Math.abs(val).toLocaleString(undefined, {maximumFractionDigits: 0})}`;
                    };

                    return `
                        <div style="padding: 12px; min-width: 220px; font-family: Inter, sans-serif;">
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                                <span style="color: #7aa2f7; font-weight: 800; font-size: 15px; letter-spacing: 0.5px;">UNIT ${location}</span>
                                <span style="color: rgba(255,255,255,0.4); font-size: 11px; font-weight: 500;">Asset #${asset}</span>
                            </div>
                            
                            <div style="background: rgba(255,255,255,0.03); border-radius: 6px; padding: 8px 10px; margin-bottom: 10px; font-size: 12px; border: 1px solid rgba(255,255,255,0.02);">
                                <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
                                    <span style="color: rgba(255,255,255,0.6)">Game</span>
                                    <span style="color: #fff; font-weight: 600;">${game}</span>
                                </div>
                                <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
                                    <span style="color: rgba(255,255,255,0.6)">Manufacturer</span>
                                    <span style="color: #fff; font-weight: 600;">${manufacturer}</span>
                                </div>
                                <div style="display: flex; justify-content: space-between;">
                                    <span style="color: rgba(255,255,255,0.6)">Link</span>
                                    <span style="color: #bb9af7; font-weight: 600;">${link}</span>
                                </div>
                            </div>

                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px; font-size: 12px;">
                                <div style="background: rgba(255, 77, 77, 0.05); border-left: 2px solid #ff4d4d; padding: 6px 8px; border-radius: 4px;">
                                    <div style="color: rgba(255,255,255,0.5); font-size: 9px; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 2px;">Turnover</div>
                                    <div style="color: #fff; font-weight: 700; font-size: 13px;">${formatMoney(turnover)}</div>
                                </div>
                                <div style="background: rgba(122, 162, 247, 0.05); border-left: 2px solid #7aa2f7; padding: 6px 8px; border-radius: 4px;">
                                    <div style="color: rgba(255,255,255,0.5); font-size: 9px; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 2px;">Win</div>
                                    <div style="color: #fff; font-weight: 700; font-size: 13px;">${formatMoney(win)}</div>
                                </div>
                                <div style="background: rgba(158, 206, 106, 0.05); border-left: 2px solid #9ece6a; padding: 6px 8px; border-radius: 4px;">
                                    <div style="color: rgba(255,255,255,0.5); font-size: 9px; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 2px;">Theo</div>
                                    <div style="color: #fff; font-weight: 700; font-size: 13px;">${formatMoney(theo)}</div>
                                </div>
                                <div style="background: rgba(224, 175, 104, 0.05); border-left: 2px solid #e0af68; padding: 6px 8px; border-radius: 4px;">
                                    <div style="color: rgba(255,255,255,0.5); font-size: 9px; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 2px;">Util / Denom</div>
                                    <div style="color: #fff; font-weight: 700; font-size: 13px;">${(util * 100).toFixed(1)}% <span style="font-weight:400; color:rgba(255,255,255,0.3)">|</span> $${denom}</div>
                                </div>
                            </div>
                        </div>
                    `;
                }
            },

            toolbox: {
                itemSize: 15,
                iconStyle: { borderColor: 'rgba(255,255,255,0.6)' },
                emphasis: { iconStyle: { borderColor: '#7aa2f7' } },
                feature: {
                    brush: {
                        type: ['rect', 'polygon', 'clear'],
                        title: { rect: 'Box Select', polygon: 'Lasso Select', clear: 'Clear Selection' }
                    }
                },
                top: 10,
                right: 10
            },
            brush: {
                toolbox: ['rect', 'polygon', 'clear'],
                xAxisIndex: 0,
                yAxisIndex: 0,
                brushLink: 'all',
                outOfBrush: { colorAlpha: 0.1 },
                brushStyle: { 
                    borderWidth: 2, 
                    color: 'rgba(122, 162, 247, 0.2)', 
                    borderColor: '#7aa2f7' 
                },
                throttleType: 'debounce',
                throttleDelay: 300,
                zlevel: 5
            },

            visualMap: {
                type: 'piecewise',
                show: true,
                dimension: 8,
                backgroundColor: 'rgba(30,30,48,0.7)',
                textStyle: { color: '#c0caf5', fontSize: 10 },
                orient: 'vertical',
                left: 5,
                bottom: 20,
                itemWidth: 12,
                itemHeight: 12,
                pieces: isCategorical 
                    ? Object.entries(
                        selectedKPI === 'Gametype' ? GAMETYPE_COLORS : 
                        selectedKPI === 'Manufacturer' ? MANUFACTURER_COLORS : 
                        LINK_COLORS
                    ).map(([k, c]) => ({ value: k, color: c, label: k }))
                    : thresholds.map(t => ({ gte: t.gte, lt: t.lt, color: t.color, label: t.label })),
                outOfRange: { color: '#404040' }
            },
            series: [{
                name: 'MainData',
                type: 'scatter',
                symbol: (val) => val.value ? val.value[4] : val[4],
                symbolRotate: (val) => val.value ? val.value[2] : val[2],
                symbolSize: (val) => val.value ? [val.value[5], val.value[6]] : [val[5], val[6]],
                itemStyle: { borderColor: '#1a1b26', borderWidth: 0.5 },
                emphasis: {
                    itemStyle: { borderWidth: 1, borderColor: '#fff' }
                }
            }]
        };

        if (isTimeline && timelineData && timelineData.length > 0) {
            const chartOptions = chart.getOption();
            const currentChartIndex = chartOptions?.timeline?.[0]?.currentIndex;

            // Only call setOption with notMerge=true if structural changes occurred.
            if (currentChartIndex !== currentIndex || !chartOptions.timeline) {
                const timelineOption = {
                    timeline: {
                        axisType: 'category',
                        data: timelineData.map(hourGroup => {
                            const hr = hourGroup[0]?.hour ?? 0;
                            return hr.toString().padStart(2, '0') + ':00';
                        }),
                        currentIndex: currentIndex,
                        autoPlay: false,
                        playInterval: 1000,
                        left: '10%', right: '10%', bottom: 0,
                        label: { color: '#7aa2f7' },
                        lineStyle: { color: '#565f89' },
                        itemStyle: { color: '#7aa2f7' },
                        checkpointStyle: { color: '#bb9af7', borderColor: '#bb9af7' },
                        controlStyle: { color: '#7aa2f7', borderColor: '#7aa2f7' }
                    },
                    baseOption: baseOption,
                    options: timelineData.map(hourData => ({
                        series: [{ data: hourData.map(mapRecord) }]
                    }))
                };
                
                const isOnlyIndexChange = chartOptions.timeline && 
                                          JSON.stringify(chartOptions.timeline[0].data) === JSON.stringify(timelineOption.timeline.data);
                
                if (isOnlyIndexChange) {
                    chart.setOption({ timeline: { currentIndex: currentIndex } }, false);
                } else {
                    chart.setOption(timelineOption, true);
                }
            }
        } else {
            const simpleOption = {
                ...baseOption,
                series: [{ ...baseOption.series[0], data: data.map(mapRecord) }]
            };
            chart.setOption(simpleOption, true);
        }

        // Handle Brush events
        chart.off('brushSelected');
        if (onBrush) {
            chart.on('brushSelected', (params) => {
                const brushed = [];
                const brushBatch = params.batch[0];
                if (brushBatch && brushBatch.selected && brushBatch.selected.length > 0) {
                    const selectedDataIndices = brushBatch.selected[0].dataIndex;
                    
                    let currentData = data;
                    if (isTimeline && timelineData) {
                        currentData = timelineData[currentIndex] || [];
                    }

                    selectedDataIndices.forEach(idx => {
                        if (currentData[idx]) {
                            brushed.push(`${currentData[idx].location}_${currentData[idx].asset}`);
                        }
                    });
                }
                
                internalBrushRef.current = brushed;
                // Only call if different to avoid infinite loops
                onBrush(brushed);
            });
        }

        const handleResize = () => chart.resize();
        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, [data, timelineData, selectedKPI, backgroundImageUrl, isTimeline, currentIndex, onTimelineChange, onBrush]);

    // Separate selection effect to avoid clearing the brush state/toolbox during selection
    useEffect(() => {
        if (!chartInstance.current) return;
        
        // Skip update if this selection was initiated by our own brush
        const isSame = selectedLocations.length === internalBrushRef.current.length &&
                       selectedLocations.every((v, i) => v === internalBrushRef.current[i]);
        if (isSame) return;
        
        const chart = chartInstance.current;

        const mapRecord = (d) => {
            const svgPath = SVG_PATHS[d.game]?.path || '';
            const sizeX = SVG_PATHS[d.game]?.sizeX || 7;
            const sizeY = SVG_PATHS[d.game]?.sizeY || 7;
            
            const field = KPI_FIELD_MAP[selectedKPI] || 'turnover';
            let val = d[field];

            // If unit is filtered out by slicers, force value to null to trigger 'outOfRange' grey color
            if (d.isFilteredOut) val = null;

            const isSelected = selectedLocations.length === 0 || selectedLocations.includes(`${d.location}_${d.asset}`);

            return {
                value: [
                    d.x, d.y, d.rotation, d.game, `path://${svgPath}`, sizeX, sizeY, d.location, val,
                    d.turnover, d.win, d.theo, d.utilization, d.denomination, d.manufacturer,
                    isSelected ? 1 : 0, d.asset, d.link
                ],
                itemStyle: {
                    opacity: isSelected ? undefined : 0.1,
                    borderWidth: isSelected ? 0.5 : 0
                }
            };
        };

        if (isTimeline && timelineData && timelineData.length > 0) {
            chart.setOption({
                options: timelineData.map(hourData => ({
                    series: [{ data: hourData.map(mapRecord) }]
                }))
            }, false);
        } else {
            chart.setOption({
                series: [{ data: data.map(mapRecord) }]
            }, false);
        }

        
        // If selection was cleared externally, also clear our internal brush visually
        if (selectedLocations.length === 0 && internalBrushRef.current.length > 0) {
            chart.dispatchAction({
                type: 'brush',
                command: 'clear',
                areas: []
            });
        }
        
        // Sync internal ref so future external clears don't get ignored by the isSame check
        internalBrushRef.current = selectedLocations;
    }, [selectedLocations, data, timelineData, selectedKPI, isTimeline]);

    return (
        <Box 
            ref={chartRef} 
            sx={{ 
                width: '100%',
                aspectRatio: '1050 / 1107',
                maxHeight: 'calc(100vh - 250px)',
                margin: '0 auto',
                border: '1px solid rgba(255,255,255,0.1)',
                borderRadius: '8px',
                boxShadow: '0 10px 30px rgba(0,0,0,0.5)',
                background: '#121212'
            }} 
        />
    );
};

export default ScatterHeatmap;

