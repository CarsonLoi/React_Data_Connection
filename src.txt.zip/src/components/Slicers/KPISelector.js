import React from 'react';
import { FormControl, InputLabel, Select, MenuItem, OutlinedInput } from '@mui/material';

const KPISelector = ({ value, onChange, options, label = "KPI Mapping" }) => {
  return (
    <FormControl sx={{ m: 1, minWidth: 220 }}>
      <InputLabel id={`kpi-selector-label-${label}`}>{label}</InputLabel>
      <Select
        labelId={`kpi-selector-label-${label}`}
        id={`kpi-selector-${label}`}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        input={<OutlinedInput label={label} />}
        size="small"
        sx={{
            bgcolor: 'rgba(122, 162, 247, 0.05)',
            '& .MuiSelect-select': { color: '#7aa2f7', fontWeight: 500 }
        }}
        MenuProps={{
          PaperProps: {
            style: {
              backgroundColor: '#1e2030',
              color: '#c0caf5',
            },
          },
        }}
      >
        {options.map((name) => (
          <MenuItem key={name} value={name} sx={{ fontSize: '0.85rem' }}>
            {name}
          </MenuItem>
        ))}
      </Select>
    </FormControl>
  );
};

export default KPISelector;
