import React from 'react';
import { FormControl, InputLabel, Select, MenuItem, OutlinedInput } from '@mui/material';

const Switcher = ({ value, onChange, options }) => {
  return (
    <FormControl sx={{ m: 1, minWidth: 120 }}>
      <InputLabel id="switcher-label">View Mode</InputLabel>
      <Select
        labelId="switcher-label"
        id="switcher-select"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        input={<OutlinedInput label="View Mode" />}
        size="small"
        sx={{
            bgcolor: 'rgba(122, 162, 247, 0.05)',
            '& .MuiSelect-select': { color: '#7aa2f7', fontWeight: 500 }
        }}
        MenuProps={{
          PaperProps: {
            style: {
              backgroundColor: '#1e2030',
              color: '#c0caf5',
            },
          },
        }}
      >
        {options.map((opt) => (
          <MenuItem key={opt} value={opt} sx={{ fontSize: '0.85rem' }}>
            {opt}
          </MenuItem>
        ))}
      </Select>
    </FormControl>
  );
};

export default Switcher;
