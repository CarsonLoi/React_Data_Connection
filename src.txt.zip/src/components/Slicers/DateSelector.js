import React from 'react';
import dayjs from 'dayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { Stack } from '@mui/material';

/**
 * Optimized DateSelector using MUI DatePickers and Dayjs.
 * Reduces redundant state by relying on props and providing clear validation.
 */
const DateSelector = ({ start, end, onStartChange, onEndChange, min, max }) => {
    
    // Convert parent string dates to dayjs objects for the component
    const startVal = dayjs(start);
    const endVal = dayjs(end);

    const handleStartChange = (newValue) => {
        if (!newValue || !newValue.isValid()) return;
        const formatted = newValue.format('YYYY-MM-DD');
        onStartChange(formatted);
        
        // Auto-correct end date if it becomes earlier than start
        if (dayjs(end).isBefore(newValue)) {
            onEndChange(formatted);
        }
    };

    const handleEndChange = (newValue) => {
        if (!newValue || !newValue.isValid()) return;
        // Strict validation: cannot select end date earlier than start
        if (newValue.isBefore(startVal)) {
            onEndChange(start);
        } else {
            onEndChange(newValue.format('YYYY-MM-DD'));
        }
    };

    const pickerStyles = {
        width: 145,
        "& .MuiOutlinedInput-root": {
            height: 32,
            fontSize: '0.75rem',
            color: "rgba(255,255,255,0.8)",
            backgroundColor: 'rgba(255,255,255,0.02)',
            "& fieldset": { borderColor: 'rgba(255,255,255,0.1)' },
            "&:hover fieldset": { borderColor: 'rgba(122, 162, 247, 0.4)' },
            "&.Mui-focused fieldset": { borderColor: '#7aa2f7', borderWidth: '1px' },
        },
        "& .MuiInputLabel-root": {
            fontSize: '0.75rem',
            color: 'rgba(255,255,255,0.3)',
            transform: 'translate(14px, 7px) scale(1)',
            "&.Mui-focused, &.MuiInputLabel-shrink": {
                transform: 'translate(14px, -8px) scale(0.75)',
                color: '#7aa2f7'
            }
        },
        "& .MuiSvgIcon-root": {
            fontSize: 16,
            color: 'rgba(255,255,255,0.5)'
        }
    };

    return (
        <LocalizationProvider dateAdapter={AdapterDayjs}>
            <Stack direction="row" spacing={1.5} sx={{ px: 1 }}>
                <DatePicker
                    label="Start Date"
                    value={startVal}
                    onChange={handleStartChange}
                    minDate={dayjs(min)}
                    maxDate={dayjs(max)}
                    format="MMM DD, YYYY"
                    slotProps={{ textField: { size: 'small' } }}
                    sx={pickerStyles}
                />
                <DatePicker
                    label="End Date"
                    value={endVal}
                    onChange={handleEndChange}
                    minDate={startVal} // Dynamically restrict end date to be >= start date
                    maxDate={dayjs(max)}
                    format="MMM DD, YYYY"
                    slotProps={{ textField: { size: 'small' } }}
                    sx={pickerStyles}
                />
            </Stack>
        </LocalizationProvider>
    );
};

export default DateSelector;
