import React from 'react';
import { FormControl, InputLabel, Select, MenuItem, OutlinedInput, Checkbox, ListItemText, Chip, Box } from '@mui/material';

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 6.5 + ITEM_PADDING_TOP,
      width: 250,
      backgroundColor: '#1e2030',
      color: '#c0caf5',
    },
  },
};

const MultiSelectSlicer = ({ label, options, selected, onChange }) => {
  const handleChange = (event) => {
    const {
      target: { value },
    } = event;
    
    // Handle "Clear" or empty case
    if (value.includes('clear')) {
      onChange([]);
      return;
    }

    // Filter out duplicates and nulls
    const filteredValue = typeof value === 'string' ? value.split(',') : value;
    onChange(filteredValue.filter(v => v !== null && v !== 'null'));
  };

  return (
    <FormControl sx={{ m: 1, minWidth: 200, maxWidth: 300 }}>
      <InputLabel id={`demo-multiple-chip-label-${label}`}>{label}</InputLabel>
      <Select
        labelId={`demo-multiple-chip-label-${label}`}
        id={`demo-multiple-chip-${label}`}
        multiple
        value={selected}
        onChange={handleChange}
        input={<OutlinedInput id={`select-multiple-chip-${label}`} label={label} />}
        renderValue={(selected) => (
          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
            {selected.length === 0 ? <Chip label="All" size="small" variant="outlined" /> : 
              selected.slice(0, 2).map((value) => (
                <Chip key={value} label={value} size="small" sx={{ height: 24, fontSize: '0.75rem', color: '#fff', bgcolor: 'rgba(78, 80, 110, 0.8)' }} />
              ))
            }
            {selected.length > 2 && <Chip label={`+${selected.length - 2}`} size="small" variant="outlined" sx={{ height: 24 }} />}
          </Box>
        )}
        MenuProps={MenuProps}
        size="small"
      >
        <MenuItem value="clear" sx={{ color: '#ff9e64', fontStyle: 'italic' }}>
          Clear Selections
        </MenuItem>
        {options.map((name) => (
          <MenuItem 
            key={name} 
            value={name}
            sx={{
              '&.Mui-selected': { backgroundColor: 'rgba(122, 162, 247, 0.2)' },
              '&.Mui-selected:hover': { backgroundColor: 'rgba(122, 162, 247, 0.3)' },
            }}
          >
            <Checkbox checked={selected.indexOf(name) > -1} size="small" sx={{ color: 'rgba(255,255,255,0.3)', '&.Mui-checked': { color: '#7aa2f7' } }} />
            <ListItemText primary={name} primaryTypographyProps={{ fontSize: '0.85rem' }} />
          </MenuItem>
        ))}
      </Select>
    </FormControl>
  );
};

export default MultiSelectSlicer;
